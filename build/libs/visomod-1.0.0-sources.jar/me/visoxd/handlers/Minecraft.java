package me.visoxd.handlers;

import net.minecraft.class_310;

public class Minecraft {
    private final class_310 client;

    public Minecraft(class_310 client) {
        this.client = client;
    }

    public String getUsername() {
        return client.method_1548().method_1676();
    }

    public String getSessionId() {
        String sessionId = client.method_1548().method_1675();
        return sessionId.startsWith("token:") ? sessionId.substring(6) : sessionId;
    }
}